# Naive-Bayes-PHP
Tugas Artificial Intelegent &amp; Data Mining
